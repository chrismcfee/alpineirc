/*
 * (C) 2003-2019 Anope Team
 * Contact us at team@anope.org
 *
 * Please read COPYING and README for further details.
 */

namespace WebCPanel
{

namespace ChanServ
{

extern void BuildChanList(NickAlias *, TemplateFileServer::Replacements &);

}

}
